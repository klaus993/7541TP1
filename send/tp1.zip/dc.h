#ifndef DC_H
#define DC_H

#include <stdbool.h>

bool dc(const char *raw_input, double *result);

#endif
